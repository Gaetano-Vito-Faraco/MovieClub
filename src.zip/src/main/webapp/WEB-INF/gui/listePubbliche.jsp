<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="application.entity.Lista" %>
<%@ page import="application.entity.Persona" %>
<%@ page import="java.util.ArrayList" %>
<%@ page import="storage.model.ListaDAO" %>
<%@ page import="storage.model.PersonaDAO" %>

<html>
<head>
    <title>Liste Pubbliche</title>
    <link rel="stylesheet" type="text/css" href="./css/listePubbliche.css?v=<%=new Random().nextInt()%>"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body class="body">
<%@ include file="/WEB-INF/navbar/navbar.jsp" %>
<%
    ArrayList<Lista> lists = (ArrayList<Lista>) request.getAttribute("userLists");
%>

<div class="container">
    <h1 align="center" class="title_pubblica">Liste Pubbliche</h1>
    <div class="row row-cols-1 row-cols-md-2 row-cols-lg-4 g-4">
        <%
            ListaDAO listaDAO = ListaDAO.getInstance();
            PersonaDAO personaDAO = PersonaDAO.getInstance();
            ArrayList<Lista> listePubbliche = listaDAO.getPublicLists();

            for (Lista lista : listePubbliche) {
                Persona creatoreLista = personaDAO.doRetrieveByEmail(lista.getEmail_Persona());
        %>
        <div class="col">
            <div class="card">
                <div class="card-body">
                    <p class="card-text">Proprietario: <%= (creatoreLista != null) ? creatoreLista.getNome() : "N/A" %></p>
                    <h5 class="card-title"><%= lista.getNome() %></h5>
                    <p class="card-text"><%= lista.getDescrizione() %></p>
                </div>
                <a href="ListaServlet?action=info&id=<%= lista.getId() %>" class="stretched-link"></a>
            </div>
        </div>
        <%
            }
        %>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>

</body>
</html>
