function validateInsert() {

    // validazione regista
    var regista = document.getElementById('regista').value.trim();
    var registaRegex = /^[A-Za-z .'\s]+$/;
    if (!registaRegex.test(regista)) {
        alert('Il campo "Regista" non può contenere numeri o caratteri speciali.');
        return false;
    }

    // valizazione copertina
    var copertina = document.getElementById('image').value.trim();
    if (copertina.length > 150) {
        alert('Lunghezza Copertina non rispettata.');
        return false;
    }

    // valizazione trailer
    var trailer = document.getElementById('trailer').value.trim();
    if (trailer.length > 100) {
        alert('Lunghezza Trailer non rispettata.');
        return false;
    }

    // validazione data
    var data = document.getElementById('data');
    if (data.value === '') {
        alert('Il campo Data è obbligatorio. Compilalo prima di inviare il modulo.');
        return false;
    }

    // validazione durata
    var durata = document.getElementById('durata').value.trim();
    var durataRegex = /^([0-9]{2}):([0-9]{2}):([0-9]{2})$/;
    if (durata !== '' && !durataRegex.test(durata)) {
        alert('Il formato della durata deve essere 00:00:00');
        return false;
    }
    var durataEmpity = document.getElementById('durata');
    if (durataEmpity.value === '') {
        // Se il campo è vuoto, imposta il valore predefinito a "00:00:00"
        durataEmpity.value = '00:00:00';
    }

    // validazione descrizione
    var descrizione = document.getElementById('descrizione').value;
    if (descrizione.length > 220 || descrizione.length<1) {
        alert('Lunghezza descrizione non rispettata.');
        return false;
    }

    // validazione generi
    var checkboxes = document.getElementsByName('generi');
    var atLeastOneChecked = false;
    for (var i = 0; i < checkboxes.length; i++) {
        if (checkboxes[i].checked) {
            atLeastOneChecked = true;
            break;
        }
    }

    if (!atLeastOneChecked) {
        alert('Seleziona almeno un genere.');
        return false;
    }

    var titolo = document.getElementById('titolo').value;
    if(titolo.length>60 || titolo.length<1){
        alert('Lunghezza titolo non rispettata.');
        return false;
    }

    var regista = document.getElementById('regista').value;
    if(regista.length>60 || regista.length<1){
        alert('Lunghezza regista non rispettata.');
        return false;
    }


    const inputDate = document.getElementById('data');
    const dataInserita = new Date(inputDate.value);
    const dataAttuale = new Date();

    // Verifica se la data inserita è nel futuro
    if (dataInserita > dataAttuale) {
        alert("Data non disponibile.");
        inputDate.value = '';
        return false;
    }

    return true;
}

function sendPostRequest(url, data) {
    var form = document.createElement('form');
    form.method = 'POST';
    form.action = url;
    // Aggiungi i dati come campi input nascosti al modulo
    for (var key in data) {
        if (data.hasOwnProperty(key)) {
            var input = document.createElement('input');
            input.type = 'hidden';
            input.name = key;
            input.value = data[key];
            form.appendChild(input);
        }
    }
    // Aggiungi il modulo alla pagina e invialo
    document.body.appendChild(form);
    form.submit();
}

function confermaEliminazione(id){
    if(confirm("Sei sicuro di voler eliminare il film?")){
        var data = { action: 'ELIMINA', id: id };
        sendPostRequest('AggiornaFilmServlet', data);
    }else{
        alert("eliminazione annullata");
    }
}

